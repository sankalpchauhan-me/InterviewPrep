package dp;

//https://www.techiedelight.com/min-throws-required-to-win-snake-and-ladder-game/
public class WinSnakeLadderGameMinThrows {

}
