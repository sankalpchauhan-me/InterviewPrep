package graphs;

//https://coderbyte.com/algorithm/find-minimum-spanning-tree-using-prims-algorithm
public class PrimsAlgoMST {

}
