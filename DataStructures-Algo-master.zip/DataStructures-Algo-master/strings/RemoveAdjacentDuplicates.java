package strings;

//https://www.techiedelight.com/in-place-remove-all-adjacent-duplicates-from-string/
//u cud consider using a stack https://www.youtube.com/watch?v=I7xTXJ4OfD4
public class RemoveAdjacentDuplicates {

}
